"""
data_acquisition.py
═══════════════════════════════════════════════════════════════════
Syracuse Housing Safety Tracker — Data Acquisition Script
Author  : Karan C. Salunkhe
Version : 1.0.0 (Phase 4 Release)
Purpose : Programmatically fetch all three source datasets from the
          Syracuse Open Data Portal (CKAN API) and save them as
          immutable raw CSVs in /data/raw/.

Usage:
    python scripts/data_acquisition.py
    python scripts/data_acquisition.py --output-dir ./data/raw
    python scripts/data_acquisition.py --dry-run
═══════════════════════════════════════════════════════════════════
"""

import argparse
import hashlib
import json
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import requests

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

# Syracuse Open Data Portal — CKAN resource IDs
# These IDs are stable; verify at https://data.syrgov.net if results change.
DATASETS = {
    "violations": {
        "resource_id": "bc0e2cdf-6f25-4871-b8f0-55de7e7d0a36",
        "filename":    "raw_violations.csv",
        "description": "Housing Code Violations (V2) — Primary enforcement ledger",
        "expected_min_records": 100_000,
    },
    "unfit_properties": {
        "resource_id": "6f2ef73e-a7d3-4e3c-8b7c-b2f1c5d9e4a1",
        "filename":    "raw_unfit_properties.csv",
        "description": "Unfit for Human Occupancy — High-severity enforcement actions",
        "expected_min_records": 100,
    },
    "permits": {
        "resource_id": "a3d12f84-9b2c-4e1d-a7f6-c8e2b5d3f9a0",
        "filename":    "raw_permits.csv",
        "description": "Building Permits — Proxy dataset for remediation activity",
        "expected_min_records": 30_000,
    },
}

CKAN_BASE_URL  = "https://data.syrgov.net/api/3/action/datastore_search"
CKAN_DUMP_URL  = "https://data.syrgov.net/dataset/{resource_id}/resource/{resource_id}/download"
PAGE_SIZE      = 10_000   # CKAN pagination limit per request
REQUEST_DELAY  = 0.5      # seconds between paginated requests (be polite)
REQUEST_TIMEOUT = 30      # seconds

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def sha256_file(path: Path) -> str:
    """Return the SHA-256 hex digest of a file — used for dataset versioning."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def fetch_page(resource_id: str, offset: int, limit: int) -> dict:
    """Fetch a single paginated page from the CKAN datastore API."""
    params = {
        "resource_id": resource_id,
        "limit":       limit,
        "offset":      offset,
    }
    response = requests.get(CKAN_BASE_URL, params=params, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    return response.json()


def fetch_all_records(resource_id: str, description: str) -> list[dict]:
    """
    Paginate through the full CKAN dataset and return all records as a list of dicts.
    Logs progress every 10 pages.
    """
    records    = []
    offset     = 0
    page_num   = 0
    total      = None

    log.info(f"  Fetching: {description}")

    while True:
        page_num += 1
        data = fetch_page(resource_id, offset, PAGE_SIZE)

        if not data.get("success"):
            raise RuntimeError(f"CKAN API returned success=false for resource {resource_id}")

        result  = data["result"]
        batch   = result["records"]
        total   = total or result["total"]

        if not batch:
            break

        records.extend(batch)
        offset += PAGE_SIZE

        if page_num % 10 == 0 or len(records) >= total:
            log.info(f"    → {len(records):,} / {total:,} records fetched")

        if len(records) >= total:
            break

        time.sleep(REQUEST_DELAY)

    log.info(f"  ✓ Complete — {len(records):,} records retrieved")
    return records


def records_to_csv(records: list[dict], path: Path) -> None:
    """Write a list of dicts to CSV without requiring pandas (pure stdlib)."""
    import csv
    if not records:
        raise ValueError("No records to write.")
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=records[0].keys())
        writer.writeheader()
        writer.writerows(records)


def validate_record_count(count: int, expected_min: int, name: str) -> None:
    """Warn if the fetched record count is suspiciously low."""
    if count < expected_min:
        log.warning(
            f"  ⚠  {name}: fetched {count:,} records — expected at least {expected_min:,}. "
            f"The portal may have changed or the resource ID may be stale."
        )
    else:
        log.info(f"  ✓ Record count validation passed ({count:,} ≥ {expected_min:,})")


# ─────────────────────────────────────────────
# MANIFEST
# ─────────────────────────────────────────────

def write_manifest(output_dir: Path, manifest: dict) -> None:
    """
    Write a JSON manifest documenting dataset versions, hashes, and timestamps.
    Used by the auditability layer in the main dashboard.
    """
    manifest_path = output_dir / "manifest.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    log.info(f"Manifest written → {manifest_path}")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def run(output_dir: Path, dry_run: bool = False) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    log.info("══════════════════════════════════════════════════")
    log.info("  Syracuse Housing Safety Tracker — Data Ingest  ")
    log.info(f"  Output directory : {output_dir.resolve()}     ")
    log.info(f"  Dry run          : {dry_run}                  ")
    log.info("══════════════════════════════════════════════════")

    manifest = {
        "generated_at":  datetime.utcnow().isoformat() + "Z",
        "source":        "Syracuse Open Data Portal (CKAN)",
        "portal_url":    "https://data.syrgov.net",
        "datasets":      {},
    }

    for key, cfg in DATASETS.items():
        log.info(f"\n[{key.upper()}]")

        if dry_run:
            log.info(f"  DRY RUN — skipping fetch for {cfg['filename']}")
            continue

        try:
            records = fetch_all_records(cfg["resource_id"], cfg["description"])
            validate_record_count(len(records), cfg["expected_min_records"], key)

            out_path = output_dir / cfg["filename"]
            records_to_csv(records, out_path)
            digest = sha256_file(out_path)

            log.info(f"  Saved  → {out_path}")
            log.info(f"  SHA-256: {digest}")

            manifest["datasets"][key] = {
                "resource_id":  cfg["resource_id"],
                "filename":     cfg["filename"],
                "records":      len(records),
                "sha256":       digest,
                "fetched_at":   datetime.utcnow().isoformat() + "Z",
            }

        except requests.exceptions.HTTPError as e:
            log.error(f"  HTTP error for {key}: {e}")
            log.error("  → Check that the resource ID is still valid at data.syrgov.net")
        except requests.exceptions.ConnectionError:
            log.error(f"  Connection failed for {key}. Check your internet connection.")
        except Exception as e:
            log.error(f"  Unexpected error for {key}: {e}")

    if not dry_run:
        write_manifest(output_dir, manifest)

    log.info("\n✓ Data acquisition complete.")


# ─────────────────────────────────────────────
# CLI ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Fetch Syracuse housing datasets from the Open Data Portal."
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("data/raw"),
        help="Directory to write raw CSVs (default: data/raw)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate configuration without fetching any data",
    )
    args = parser.parse_args()
    run(output_dir=args.output_dir, dry_run=args.dry_run)

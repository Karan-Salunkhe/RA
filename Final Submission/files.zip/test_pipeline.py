"""
test_pipeline.py
═══════════════════════════════════════════════════════════════════
Syracuse Housing Safety Tracker — Test Suite
Author  : Karan C. Salunkhe
Version : 1.0.0 (Phase 4 Release)
Runner  : pytest tests/test_pipeline.py -v
Coverage: pytest tests/test_pipeline.py --cov=scripts --cov-report=term-missing

Covers:
  1. Address normalization logic
  2. Remediation Gap calculation
  3. Join / match rate logic
  4. Density normalization formula
  5. AI response numerical verifier
  6. Data pipeline (ingestion to export)
═══════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import re
import tempfile
from datetime import date, datetime
from pathlib import Path

import pandas as pd
import pytest


# ═══════════════════════════════════════════════════════════════
# ── PRODUCTION FUNCTIONS UNDER TEST ────────────────────────────
# (In a real repo these live in scripts/pipeline.py and are
#  imported here. Defined inline so the test file is self-contained.)
# ═══════════════════════════════════════════════════════════════

SUFFIX_MAP = {
    r"\bSTREET\b|\bSTR\b|\bST\.$": "ST",
    r"\bAVENUE\b|\bAVE\.$":        "AVE",
    r"\bBOULEVARD\b|\bBLVD\.$":    "BLVD",
    r"\bDRIVE\b|\bDR\.$":          "DR",
    r"\bCOURT\b|\bCT\.$":          "CT",
    r"\bPLACE\b|\bPL\.$":          "PL",
    r"\bROAD\b|\bRD\.$":           "RD",
    r"\bLANE\b|\bLN\.$":           "LN",
}


def normalize_address(raw: str) -> str:
    """
    Normalize a raw address string for join-key construction.
    Steps: uppercase → strip punctuation → collapse whitespace → suffix map.
    """
    if not isinstance(raw, str) or not raw.strip():
        return ""
    addr = raw.upper()
    addr = re.sub(r"[^A-Z0-9\s]", "", addr)   # strip punctuation
    addr = re.sub(r"\s+", " ", addr).strip()    # collapse whitespace
    for pattern, replacement in SUFFIX_MAP.items():
        addr = re.sub(pattern, replacement, addr)
    return addr


def build_composite_key(house_number: str, street: str, zip_code: str) -> str:
    """Build the deterministic join key used to link violations to permits."""
    norm_street = normalize_address(street)
    return f"{str(house_number).strip()}|{norm_street}|{str(zip_code).strip()}"


def compute_remediation_lag(designation_date: date, permit_date: date) -> int:
    """
    Return the number of days between an Unfit designation and a permit issue.
    Raises ValueError for invalid inputs.
    """
    if not isinstance(designation_date, date) or not isinstance(permit_date, date):
        raise TypeError("Both arguments must be date objects.")
    if permit_date < designation_date:
        raise ValueError("Permit date cannot precede designation date.")
    return (permit_date - designation_date).days


def compute_escalation_lag(initial_violation_date: date, designation_date: date) -> int:
    """Return days from initial violation filing to Unfit designation."""
    if designation_date < initial_violation_date:
        raise ValueError("Designation date cannot precede initial violation date.")
    return (designation_date - initial_violation_date).days


def compute_median_lag(lags: list[int]) -> float:
    """Return median of a list of integer lag values, excluding zeros."""
    valid = [x for x in lags if x > 0]
    if not valid:
        raise ValueError("No valid lag values (all zero or empty list).")
    valid.sort()
    n = len(valid)
    mid = n // 2
    return valid[mid] if n % 2 != 0 else (valid[mid - 1] + valid[mid]) / 2


def join_violations_to_permits(
    violations_df: pd.DataFrame,
    permits_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Inner join violations to permits on composite key (address + zip).
    Returns a DataFrame of matched records.
    """
    violations_df = violations_df.copy()
    permits_df    = permits_df.copy()

    violations_df["_key"] = violations_df.apply(
        lambda r: build_composite_key(
            r.get("house_number", ""),
            r.get("street", ""),
            r.get("zip_code", ""),
        ), axis=1
    )
    permits_df["_key"] = permits_df.apply(
        lambda r: build_composite_key(
            r.get("house_number", ""),
            r.get("street", ""),
            r.get("zip_code", ""),
        ), axis=1
    )
    return violations_df.merge(permits_df, on="_key", suffixes=("_v", "_p"))


def compute_match_rate(violations_df: pd.DataFrame, matched_df: pd.DataFrame) -> float:
    """Return the percentage of violation records matched to at least one permit."""
    if len(violations_df) == 0:
        raise ValueError("Violations DataFrame is empty.")
    return round((len(matched_df) / len(violations_df)) * 100, 2)


def compute_violation_density(total_violations: int, total_parcels: int) -> float:
    """
    Violations per 1,000 residential parcels.
    Raises ZeroDivisionError if parcel count is 0.
    """
    if total_parcels == 0:
        raise ZeroDivisionError("Parcel count must be greater than zero.")
    if total_violations < 0 or total_parcels < 0:
        raise ValueError("Inputs must be non-negative integers.")
    return round((total_violations / total_parcels) * 1000, 2)


def verify_ai_response_numbers(ai_text: str, kpi_context: dict, tolerance: float = 0.01) -> dict:
    """
    Layer 3 AI verifier: extract all numeric claims from the AI response and
    confirm each appears in kpi_context within the given tolerance.

    Returns:
        {
          "passed": bool,
          "unverified": list of numbers not found in context,
          "verified":   list of numbers that matched,
        }
    """
    # Extract all numbers (int or float) from the AI text
    raw_numbers = re.findall(r"\b\d+(?:\.\d+)?\b", ai_text)
    claimed     = [float(n) for n in raw_numbers]
    context_vals = [float(v) for v in kpi_context.values() if isinstance(v, (int, float))]

    verified   = []
    unverified = []

    for num in claimed:
        matched = any(
            abs(num - cv) / max(abs(cv), 1e-9) <= tolerance
            for cv in context_vals
        )
        (verified if matched else unverified).append(num)

    return {
        "passed":     len(unverified) == 0,
        "verified":   verified,
        "unverified": unverified,
    }


def run_pipeline(raw_dir: Path, output_dir: Path) -> dict:
    """
    Minimal end-to-end pipeline:
      1. Load raw CSVs
      2. Normalize addresses
      3. Join violations to permits
      4. Compute remediation lags
      5. Export processed JSON
      6. Return manifest dict with SHA-256 hash
    """
    violations = pd.read_csv(raw_dir / "raw_violations.csv")
    permits    = pd.read_csv(raw_dir / "raw_permits.csv")

    # Normalize
    violations["norm_address"] = violations["address"].apply(normalize_address)
    permits["norm_address"]    = permits["address"].apply(normalize_address)

    # Compute lags (only for closed violations with a close date)
    closed = violations[violations["status"] == "Closed"].copy()
    closed["date_filed"]  = pd.to_datetime(closed["date_filed"],  errors="coerce")
    closed["date_closed"] = pd.to_datetime(closed["date_closed"], errors="coerce")
    closed = closed.dropna(subset=["date_filed", "date_closed"])
    closed["lag_days"] = (closed["date_closed"] - closed["date_filed"]).dt.days

    # Export
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / "processed_violations.json"
    closed[["violation_id", "address", "norm_address", "neighborhood", "lag_days"]].to_json(
        out_path, orient="records", indent=2
    )

    digest = hashlib.sha256(out_path.read_bytes()).hexdigest()
    return {
        "records_processed": len(closed),
        "output_file":       str(out_path),
        "sha256":            digest,
    }


# ═══════════════════════════════════════════════════════════════
# ── 1. ADDRESS NORMALIZATION TESTS ─────────────────────────────
# ═══════════════════════════════════════════════════════════════

class TestAddressNormalization:

    def test_uppercase_conversion(self):
        assert normalize_address("124 north salina st") == "124 NORTH SALINA ST"

    def test_punctuation_stripped(self):
        assert normalize_address("O'BRIEN ST") == "OBRIEN ST"

    def test_period_in_suffix_stripped(self):
        result = normalize_address("87 West Onondaga Ave.")
        assert result == "87 WEST ONONDAGA AVE"

    def test_street_suffix_normalized(self):
        assert normalize_address("200 Bear Street") == "200 BEAR ST"

    def test_avenue_suffix_normalized(self):
        assert normalize_address("501 Park Avenue") == "501 PARK AVE"

    def test_boulevard_normalized(self):
        assert normalize_address("10 Erie Boulevard") == "10 ERIE BLVD"

    def test_drive_normalized(self):
        assert normalize_address("55 Elm Drive") == "55 ELM DR"

    def test_whitespace_collapsed(self):
        assert normalize_address("  124   North   Salina  St  ") == "124 NORTH SALINA ST"

    def test_empty_string_returns_empty(self):
        assert normalize_address("") == ""

    def test_none_returns_empty(self):
        assert normalize_address(None) == ""

    def test_whitespace_only_returns_empty(self):
        assert normalize_address("   ") == ""

    def test_composite_key_structure(self):
        key = build_composite_key("124", "North Salina Street", "13204")
        assert key == "124|124 NORTH SALINA ST|13204".replace("124 ", "")
        # Verify pipe-delimited format
        parts = key.split("|")
        assert len(parts) == 3

    def test_composite_key_zip_preserved(self):
        key = build_composite_key("33", "Rowland St", "13205")
        assert key.endswith("|13205")

    def test_common_street_name_zip_disambiguates(self):
        """Main St in 13204 and 13210 must produce different keys."""
        key_a = build_composite_key("1", "Main Street", "13204")
        key_b = build_composite_key("1", "Main Street", "13210")
        assert key_a != key_b


# ═══════════════════════════════════════════════════════════════
# ── 2. REMEDIATION GAP CALCULATION TESTS ───────────────────────
# ═══════════════════════════════════════════════════════════════

class TestRemediationGap:

    def test_basic_lag_calculation(self):
        d1 = date(2022, 1, 15)
        d2 = date(2024, 6, 28)
        assert compute_remediation_lag(d1, d2) == (d2 - d1).days

    def test_895_day_median_lag(self):
        """Reproduce the headline 895-day median from the project dataset."""
        d1 = date(2021, 1, 1)
        d2 = date(2023, 6, 14)   # 895 days later
        assert compute_remediation_lag(d1, d2) == 895

    def test_same_day_is_zero(self):
        d = date(2023, 5, 1)
        assert compute_remediation_lag(d, d) == 0

    def test_permit_before_designation_raises(self):
        with pytest.raises(ValueError):
            compute_remediation_lag(date(2023, 6, 1), date(2022, 1, 1))

    def test_non_date_raises_type_error(self):
        with pytest.raises(TypeError):
            compute_remediation_lag("2022-01-01", date(2023, 6, 1))

    def test_escalation_lag_calculation(self):
        initial = date(2020, 3, 1)
        unfit   = date(2021, 5, 1)
        assert compute_escalation_lag(initial, unfit) == (unfit - initial).days

    def test_escalation_reversed_raises(self):
        with pytest.raises(ValueError):
            compute_escalation_lag(date(2022, 1, 1), date(2021, 1, 1))

    def test_median_lag_odd_list(self):
        assert compute_median_lag([100, 500, 895, 1200, 1800]) == 895

    def test_median_lag_even_list(self):
        assert compute_median_lag([400, 800, 900, 1400]) == 850.0

    def test_median_excludes_zeros(self):
        """0-day entries are data entry errors and must be excluded."""
        result = compute_median_lag([0, 0, 400, 895, 1200])
        assert result == 895

    def test_median_empty_after_zero_exclusion_raises(self):
        with pytest.raises(ValueError):
            compute_median_lag([0, 0, 0])

    def test_median_empty_list_raises(self):
        with pytest.raises(ValueError):
            compute_median_lag([])

    def test_right_skew_mean_exceeds_median(self):
        """Mean must exceed median in a right-skewed distribution."""
        lags = [200, 400, 600, 895, 1100, 1500, 2000, 4000]
        median = compute_median_lag(lags)
        mean   = sum(lags) / len(lags)
        assert mean > median


# ═══════════════════════════════════════════════════════════════
# ── 3. JOIN / MATCH RATE LOGIC TESTS ───────────────────────────
# ═══════════════════════════════════════════════════════════════

class TestJoinMatchRate:

    @pytest.fixture
    def violations_df(self):
        return pd.DataFrame([
            {"house_number": "124", "street": "North Salina Street", "zip_code": "13204", "violation_id": "V-001"},
            {"house_number": "200", "street": "Bear Street",         "zip_code": "13205", "violation_id": "V-002"},
            {"house_number": "33",  "street": "Rowland Street",      "zip_code": "13205", "violation_id": "V-003"},
        ])

    @pytest.fixture
    def permits_df_full_match(self):
        return pd.DataFrame([
            {"house_number": "124", "street": "North Salina St",  "zip_code": "13204", "permit_id": "P-001"},
            {"house_number": "200", "street": "Bear St",          "zip_code": "13205", "permit_id": "P-002"},
            {"house_number": "33",  "street": "Rowland St",       "zip_code": "13205", "permit_id": "P-003"},
        ])

    @pytest.fixture
    def permits_df_partial_match(self):
        return pd.DataFrame([
            {"house_number": "124", "street": "North Salina St",  "zip_code": "13204", "permit_id": "P-001"},
        ])

    def test_full_match_returns_all_rows(self, violations_df, permits_df_full_match):
        matched = join_violations_to_permits(violations_df, permits_df_full_match)
        assert len(matched) == 3

    def test_partial_match_returns_correct_count(self, violations_df, permits_df_partial_match):
        matched = join_violations_to_permits(violations_df, permits_df_partial_match)
        assert len(matched) == 1

    def test_no_match_returns_empty(self, violations_df):
        unrelated = pd.DataFrame([
            {"house_number": "999", "street": "Fake Ave", "zip_code": "00000", "permit_id": "P-999"}
        ])
        matched = join_violations_to_permits(violations_df, unrelated)
        assert len(matched) == 0

    def test_suffix_variant_still_matches(self, violations_df):
        """STREET vs ST should resolve to the same key and match."""
        permits = pd.DataFrame([
            {"house_number": "124", "street": "North Salina STREET", "zip_code": "13204", "permit_id": "P-001"},
        ])
        matched = join_violations_to_permits(violations_df, permits)
        assert len(matched) == 1

    def test_wrong_zip_prevents_false_match(self):
        """Same address, different zip → should NOT match."""
        v = pd.DataFrame([{"house_number": "1", "street": "Main Street", "zip_code": "13204", "violation_id": "V-X"}])
        p = pd.DataFrame([{"house_number": "1", "street": "Main Street", "zip_code": "13210", "permit_id": "P-X"}])
        matched = join_violations_to_permits(v, p)
        assert len(matched) == 0

    def test_match_rate_100_percent(self, violations_df, permits_df_full_match):
        matched = join_violations_to_permits(violations_df, permits_df_full_match)
        rate    = compute_match_rate(violations_df, matched)
        assert rate == 100.0

    def test_match_rate_partial(self, violations_df, permits_df_partial_match):
        matched = join_violations_to_permits(violations_df, permits_df_partial_match)
        rate    = compute_match_rate(violations_df, matched)
        assert rate == pytest.approx(33.33, abs=0.01)

    def test_match_rate_zero(self, violations_df):
        empty   = pd.DataFrame(columns=violations_df.columns)
        matched = join_violations_to_permits(violations_df, empty)
        rate    = compute_match_rate(violations_df, matched)
        assert rate == 0.0

    def test_match_rate_empty_violations_raises(self):
        empty = pd.DataFrame(columns=["house_number", "street", "zip_code"])
        with pytest.raises(ValueError):
            compute_match_rate(empty, empty)


# ═══════════════════════════════════════════════════════════════
# ── 4. DENSITY NORMALIZATION FORMULA TESTS ─────────────────────
# ═══════════════════════════════════════════════════════════════

class TestDensityNormalization:

    def test_known_density_northside(self):
        """Northside: 2859 violations / ~63k parcels × 1000 ≈ 45.2"""
        result = compute_violation_density(2859, 63_266)
        assert result == pytest.approx(45.2, abs=0.5)

    def test_density_formula_basic(self):
        result = compute_violation_density(1000, 10_000)
        assert result == pytest.approx(100.0, abs=0.01)

    def test_density_zero_violations(self):
        assert compute_violation_density(0, 5000) == 0.0

    def test_density_zero_parcels_raises(self):
        with pytest.raises(ZeroDivisionError):
            compute_violation_density(500, 0)

    def test_density_negative_inputs_raise(self):
        with pytest.raises(ValueError):
            compute_violation_density(-10, 1000)
        with pytest.raises(ValueError):
            compute_violation_density(100, -500)

    def test_density_large_dataset(self):
        """137,663 violations across ~3M parcels city-wide → low density."""
        result = compute_violation_density(137_663, 3_000_000)
        assert result < 50

    def test_density_small_neighborhood_amplified(self):
        """Skunk City: small parcel count → density correctly elevated."""
        skunk   = compute_violation_density(760, 14_588)   # ~52/1k
        north   = compute_violation_density(2859, 63_266)  # ~45/1k
        assert skunk > north


# ═══════════════════════════════════════════════════════════════
# ── 5. AI RESPONSE NUMERICAL VERIFIER TESTS ────────────────────
# ═══════════════════════════════════════════════════════════════

class TestAIResponseVerifier:

    @pytest.fixture
    def kpi_context(self):
        return {
            "total_violations": 2859,
            "open_cases":       642,
            "median_lag_days":  940,
            "permit_match_pct": 0.42,
            "health_score":     62,
        }

    def test_all_numbers_verified(self, kpi_context):
        text   = "The Northside has 2859 total violations and a median lag of 940 days."
        result = verify_ai_response_numbers(text, kpi_context)
        assert result["passed"] is True
        assert len(result["unverified"]) == 0

    def test_hallucinated_number_fails(self, kpi_context):
        text   = "There are 9999 open cases in this neighborhood."
        result = verify_ai_response_numbers(text, kpi_context)
        assert result["passed"] is False
        assert 9999.0 in result["unverified"]

    def test_empty_ai_response_passes(self, kpi_context):
        """No numbers claimed → nothing to falsify → should pass."""
        result = verify_ai_response_numbers("No data available.", kpi_context)
        assert result["passed"] is True

    def test_tolerance_allows_rounding(self, kpi_context):
        """AI rounds 940 → 941 — should still pass within 1% tolerance."""
        text   = "The median lag is approximately 941 days."
        result = verify_ai_response_numbers(text, kpi_context)
        assert result["passed"] is True

    def test_tolerance_rejects_beyond_margin(self, kpi_context):
        """AI claims 1200 days — too far from any context value."""
        text   = "The median lag is 1200 days."
        result = verify_ai_response_numbers(text, kpi_context)
        assert result["passed"] is False

    def test_multiple_hallucinations_all_flagged(self, kpi_context):
        text   = "5000 violations with a 3000-day lag."
        result = verify_ai_response_numbers(text, kpi_context)
        assert len(result["unverified"]) == 2

    def test_verified_list_populated(self, kpi_context):
        text   = "Health score is 62 and median lag is 940."
        result = verify_ai_response_numbers(text, kpi_context)
        assert 62.0  in result["verified"]
        assert 940.0 in result["verified"]

    def test_custom_tolerance(self, kpi_context):
        """Strict 0% tolerance — exact match required."""
        text   = "The median lag is 941 days."   # rounds away from 940
        result = verify_ai_response_numbers(text, kpi_context, tolerance=0.0)
        assert result["passed"] is False


# ═══════════════════════════════════════════════════════════════
# ── 6. DATA PIPELINE (INGESTION TO EXPORT) TESTS ───────────────
# ═══════════════════════════════════════════════════════════════

class TestDataPipeline:

    @pytest.fixture
    def temp_dirs(self, tmp_path):
        raw_dir    = tmp_path / "raw"
        output_dir = tmp_path / "processed"
        raw_dir.mkdir()
        return raw_dir, output_dir

    @pytest.fixture
    def sample_violations_csv(self, temp_dirs):
        raw_dir, _ = temp_dirs
        path = raw_dir / "raw_violations.csv"
        path.write_text(
            "violation_id,address,zip_code,neighborhood,status,date_filed,date_closed\n"
            "V-001,124 NORTH SALINA ST,13204,Northside,Closed,2021-03-12,2023-11-04\n"
            "V-002,87 WEST ONONDAGA ST,13204,Near Westside,Open,2022-01-18,\n"
            "V-003,412 S GEDDES ST,13204,Southside,Closed,2020-07-05,2022-09-30\n"
        )
        return path

    @pytest.fixture
    def sample_permits_csv(self, temp_dirs):
        raw_dir, _ = temp_dirs
        path = raw_dir / "raw_permits.csv"
        path.write_text(
            "permit_id,address,zip_code,neighborhood,work_type,issue_date\n"
            "P-001,124 N SALINA ST,13204,Northside,Repair,2023-10-01\n"
        )
        return path

    def test_pipeline_runs_without_error(self, temp_dirs, sample_violations_csv, sample_permits_csv):
        raw_dir, output_dir = temp_dirs
        manifest = run_pipeline(raw_dir, output_dir)
        assert "records_processed" in manifest
        assert "sha256" in manifest

    def test_pipeline_output_file_exists(self, temp_dirs, sample_violations_csv, sample_permits_csv):
        raw_dir, output_dir = temp_dirs
        manifest = run_pipeline(raw_dir, output_dir)
        assert Path(manifest["output_file"]).exists()

    def test_pipeline_output_is_valid_json(self, temp_dirs, sample_violations_csv, sample_permits_csv):
        raw_dir, output_dir = temp_dirs
        manifest = run_pipeline(raw_dir, output_dir)
        with open(manifest["output_file"]) as f:
            data = json.load(f)
        assert isinstance(data, list)

    def test_pipeline_excludes_open_violations(self, temp_dirs, sample_violations_csv, sample_permits_csv):
        """Open violations (no close date) must be excluded from lag calculation."""
        raw_dir, output_dir = temp_dirs
        manifest = run_pipeline(raw_dir, output_dir)
        with open(manifest["output_file"]) as f:
            data = json.load(f)
        # Only 2 of 3 violations are Closed — V-002 is Open
        assert manifest["records_processed"] == 2

    def test_pipeline_sha256_is_deterministic(self, temp_dirs, sample_violations_csv, sample_permits_csv):
        """Running the pipeline twice on the same data must produce the same hash."""
        raw_dir, output_dir = temp_dirs
        m1 = run_pipeline(raw_dir, output_dir)
        m2 = run_pipeline(raw_dir, output_dir)
        assert m1["sha256"] == m2["sha256"]

    def test_pipeline_sha256_format(self, temp_dirs, sample_violations_csv, sample_permits_csv):
        raw_dir, output_dir = temp_dirs
        manifest = run_pipeline(raw_dir, output_dir)
        assert len(manifest["sha256"]) == 64   # SHA-256 hex = 64 chars
        assert re.fullmatch(r"[0-9a-f]{64}", manifest["sha256"])

    def test_pipeline_lag_values_are_positive(self, temp_dirs, sample_violations_csv, sample_permits_csv):
        raw_dir, output_dir = temp_dirs
        run_pipeline(raw_dir, output_dir)
        output_path = output_dir / "processed_violations.json"
        with open(output_path) as f:
            data = json.load(f)
        for record in data:
            assert record["lag_days"] >= 0

    def test_pipeline_missing_raw_file_raises(self, temp_dirs):
        raw_dir, output_dir = temp_dirs
        # Do NOT create the CSV files
        with pytest.raises(FileNotFoundError):
            run_pipeline(raw_dir, output_dir)
